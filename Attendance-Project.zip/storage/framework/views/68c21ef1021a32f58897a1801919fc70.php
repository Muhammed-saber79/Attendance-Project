<!doctype html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <title>Attendance | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Simple bar CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/simplebar.css')); ?>">
    <!-- Fonts CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Overpass:ital,wght@0,100;0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- Icons CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/feather.css')); ?>">
    <!-- Date Range Picker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/daterangepicker.css')); ?>">
    <!-- App CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app-light.css')); ?>" id="lightTheme" disabled>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/app-dark.css')); ?>" id="darkTheme">
</head>
    <body class="dark rtl">
        <?php if (isset($component)) { $__componentOriginalabfd08d099e5120d99fc78cfc4d6eb8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabfd08d099e5120d99fc78cfc4d6eb8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toaster','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('toaster'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabfd08d099e5120d99fc78cfc4d6eb8e)): ?>
<?php $attributes = $__attributesOriginalabfd08d099e5120d99fc78cfc4d6eb8e; ?>
<?php unset($__attributesOriginalabfd08d099e5120d99fc78cfc4d6eb8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabfd08d099e5120d99fc78cfc4d6eb8e)): ?>
<?php $component = $__componentOriginalabfd08d099e5120d99fc78cfc4d6eb8e; ?>
<?php unset($__componentOriginalabfd08d099e5120d99fc78cfc4d6eb8e); ?>
<?php endif; ?>
        <div class="wrapper vh-100">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/daterangepicker.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.stickOnScroll.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/tinycolor-min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/apps.js')); ?>"></script>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag()
            {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());
            gtag('config', 'UA-56159088-1');
        </script>
    </body>
</html>
<?php /**PATH D:\laragon\www\Attendance-Project\resources\views/Layouts/auth.blade.php ENDPATH**/ ?>