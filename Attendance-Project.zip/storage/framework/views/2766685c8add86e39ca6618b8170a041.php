<?php $__env->startSection('title'); ?>
    معاملات الإداريين
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main role="main" class="main-content">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12">
                    <h2 class="mb-2 page-title">معاملات الإداريين في حالة الغياب</h2>
                    <div class="row my-4">
                        <!-- جدول صغير -->
                        <div class="col-md-12">
                            <div class="card shadow">
                                <div class="card-body">
                                    <!-- الجدول -->
                                    <table class="table datatables" id="dataTable-1">
                                        <thead>
                                        <tr>
                                            <th>رقم الموظف</th>
                                            <th>الاسم</th>
                                            <th>الإدارة التابع لها</th>
                                            <th>الهاتف</th>
                                            <th>البريد الإلكتروني</th>
                                            <th>تاريخ الغياب</th>
                                            <th>حالة التواصل</th>
                                            <th>تاريخ الإرسال</th>
                                            <th>الصورة الشخصية</th>
                                            <th>الإجراء</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php $__empty_1 = true; $__currentLoopData = $absentEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <?php
                                                $empData = \App\Models\Employee::with(['messages'])->find($absent->employee_id);
                                            ?>
                                            <tr>
                                                <td><?php echo e(@$absent->employee->number); ?></td>
                                                <td><?php echo e(@$absent->employee->name); ?></td>
                                                <td><?php echo e(@$absent->employee->department); ?></td>
                                                <td><?php echo e(@$absent->employee->phone); ?></td>
                                                <td><?php echo e(@$absent->employee->email); ?></td>
                                                <td><?php echo e(@$absent->created_at->format('d-m-Y')); ?></td>
                                                <td>
                                                    <?php if(@$absent->is_replied): ?>
                                                        <span class="text-success">تم إرسال اشعار</span>
                                                    <?php else: ?>
                                                        <span class="text-warning">لم يتم إرسال اشعار</span>
                                                    <?php endif; ?>
                                                </td>

                                                <?php if(@$absent->is_replied): ?>
                                                    <?php
                                                        $message = $empData->messages()->where('type', 'notification')->whereDate('created_at', '>=', now()->subDays(2))->first();
                                                    ?>
                                                    <td class="text-info"><?php echo e($message->created_at->diffForHumans()); ?></td>
                                                <?php else: ?>
                                                    <td class="text-info">لم يحدد بعد</td>
                                                <?php endif; ?>

                                                <td>
                                                    <img src="<?php echo e(@$empData->getFirstMediaUrl('image', 'thumb')); ?>" width="75px" alt="صورة الموظف">
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm dropdown-toggle more-horizontal" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <span class="text-muted sr-only">الإجراء</span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a class="dropdown-item" data-toggle="modal" data-target="#editEmployeeModal_<?php echo e(@$empData->id); ?>">اشعار حسم</a>
                                                        <a class="dropdown-item" href="" <?php if(@$absent->is_replied): ?> data-toggle="modal" data-target="#decideEmployee_-<?php echo e(@$empData->id); ?>" <?php endif; ?>>قرار حسم</a>
                                                    </div>
                                                </td>

                                                <!-- Modal for edit employee data -->
                                                <div class="modal fade" id="editEmployeeModal_<?php echo e(@$empData->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editEmployeeModal_<?php echo e(@$empData->id); ?>" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="editEmployeeModal_<?php echo e(@$empData->id); ?>">إرسال إشعار حسم</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form action="<?php echo e(route('admin.messages.notifyEmployee', @$empData->id)); ?>" method="post" id="editTemplateForm_<?php echo e(@$empData->id); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="form-group">
                                                                        <label for="title">عنوان الرسالة:</label>
                                                                        <input type="text" class="form-control" id="title" name="title" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="description">محتوى الرسالة:</label>
                                                                        <textarea class="form-control" id="description" name="description" required></textarea>
                                                                    </div>
                                                                    <input type="hidden" name="type" value="notification">
                                                                </form>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                                                <button type="submit" class="btn btn-primary" form="editTemplateForm_<?php echo e(@$empData->id); ?>">إرسال</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Modal for delete an employee -->
                                                <div class="modal fade" id="decideEmployee_-<?php echo e(@$empData->id); ?>" tabindex="-1" role="dialog" aria-labelledby="decideEmployee_-<?php echo e(@$empData->id); ?>" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="addTemplateModalLabel">إرسال قرار حسم</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form action="<?php echo e(route('admin.messages.decideEmployee', @$empData->id)); ?>" method="post" id="decideEmployee_<?php echo e(@$empData->id); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="form-group">
                                                                        <label for="title">عنوان الرسالة:</label>
                                                                        <input type="text" class="form-control" id="title" name="title" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="description">محتوى الرسالة:</label>
                                                                        <textarea class="form-control" id="description" name="description" required></textarea>
                                                                    </div>
                                                                    <input type="hidden" name="type" value="decision">
                                                                </form>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                                                <button type="submit" class="btn btn-primary" form="decideEmployee_<?php echo e(@$absent->id); ?>">إرسال</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td style="color: red; text-align: center" colspan="7">لا يوجد إداريين مسجلين بالمنصة حتى الان</td>
                                            </tr>
                                        <?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div> <!-- الجدول البسيط -->
                    </div> <!-- نهاية القسم -->
                </div> <!-- .col-12 -->

            </div> <!-- .row -->
        </div> <!-- .container-fluid -->
    </main> <!-- main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Attendance-Project\resources\views/Admin/Employees/absent.blade.php ENDPATH**/ ?>